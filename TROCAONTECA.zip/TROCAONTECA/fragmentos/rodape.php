
  <footer class="fixed-bottom py-1 bg-primary text-body">
    <div class="container text-center">
      Desenvolvido por Antônio Carlos e Luís Miguel.
    </div>
  </footer>

  <!-- Optional JavaScript; choose one of the two! -->
  <!-- Option 1: Bootstrap Bundle with Popper -->
  <script src="bibliotecas/bootstrap-5.0.1-dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
