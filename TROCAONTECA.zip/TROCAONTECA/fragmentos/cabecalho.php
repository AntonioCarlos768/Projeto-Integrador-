
<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Bootstrap CSS -->
  <link href="bibliotecas/bootstrap-5.0.1-dist/css/bootstrap.min.css" rel="stylesheet">

  <!-- layout personalizado -->
  <link rel="stylesheet" href="layout/meuestilo.css">

  <title> <?= $titulo ?> </title>
</head>

<body class="pt-5">

