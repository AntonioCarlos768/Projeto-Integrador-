<?php
include "_funcoesConfigBanco.php";
$titulo = "TROCAONTECA";
include "fragmentos/cabecalho.php"; // incluir o cabecalho
include "fragmentos/menu2.php"; // incluir o menu

$con = conectarBanco("trocaonteca");

/*
$dadosMax = executarSelect($con, "SELECT max(codigo) as maximo FROM livro");
print_r($dadosMax);
$maxId = $dadosMax[0]["maximo"];
$proximoId = $maxId + 1; 
*/



$livros  = executarSelect($con, "SELECT codigo, titulo, autor, sinopse ,u.codigo FROM livro, u.usuario ORDER BY titulo");
print_r($livros);
desconectarBanco($con);


?>
<br><br>
<div class="container mb-5 ">

    <div class="row py-10">
         

    </div>          
  <br><br> 
     <div class="row col-8">
      <form action="SalvarLivro.php"  method="POST" enctype="multipart/form-data">
       
      <div class="row col-8 mt-5">
      
      <div class="mb-3 col-8">
        
        <label for="codigous" class="form-label">Código do Usuario</label>
                     <input type="number" class="form-control" name="codigous" id="codigous" >
        </div>
       </div>

      <div class="mb-3 col-8">
        
        <label for="codigo" class="form-label">Código do Livro</label>
                     <input type="number" class="form-control" name="codigo" id="codigo" >
        </div>
       </div>

      <div class="mb-3 col-8">
    <label for="titulo" class="Titulo">Título:</label>
    <input type="text" class="form-control" name="titulo" id="titulo" aria-describedby="coloque o titulo" required>
    <div id="titulo" class="form-text">Insira o titulo</div>
  </div>
  

  <div class="mb-3 col-8">
    <label for="autor" class="autor">Autor:</label>
    <input type="text" class="form-control" name="autor" id="autor" required>
  </div>

  
  <div class="form-check form-check-inline">
  <input type="checkbox" id="genero" name="genero" value="3">
<label for="terror"> Terror</label><br>
</div>

<div class="form-check form-check-inline">
<input type="checkbox" id="genero" name="genero" value="4">
<label for="aventura"> Aventura</label><br>
</div>


<div class="form-check form-check-inline">
<input type="checkbox" id="misterio" name="misterio" value="misterio">
<label for="misterio"> Mistério</label><br>
</div>


<div class="form-check form-check-inline">
<input type="checkbox" id="religioso" name="religioso" value="religioso">
<label for="religioso"> Religioso</label><br>
</div>

<div class="form-check form-check-inline">
<input type="checkbox" id="suspense" name="suspense" value="suspense">
<label for="suspense"> Suspense</label><br>
</div>

<div class="form-check form-check-inline">
<input type="checkbox" id="romance" name="romance" value="romance">
<label for="romance"> Romance</label><br>
</div>

<div class="form-check form-check-inline">
<input type="checkbox" id="hq" name="hq" value="hq">
<label for="hq"> HQ</label><br>
</div>

<div class="form-check form-check-inline">
<input type="checkbox" id="ficcao" name="ficcao" value="ficcao">
<label for="ficcao"> Ficção</label>
</div> 

<div class="form-check form-check-inline">
<input type="checkbox" id="fantasia" name="fantasia" value="fantasia">
<label for="fantasia"> Fantasia</label>
</div> 

<div class="form-check form-check-inline">
<input type="checkbox" id="nao_ficcao" name="ficcao" value="nao_ficcao">
<label for="nao_ficcao"> Não ficção</label>
</div> 

<div class="form-check form-check-inline">
<input type="checkbox" id="polical" name="policial" value="policial">
<label for="policial"> Policial</label>
</div> 

<div class="form-check form-check-inline">
<input type="checkbox" id="biografia" name="biografia" value="biografia">
<label for="ficcao"> Biografia</label>
</div> 

<br><br>

          <div class="mb-3">
                    <label for="imagem" class="form-label">Imagem do Livro</label>
                    <input type="file" class="form-control" name="imagem" id="imagem" accept="image/png, image/jpeg" required>                    
                </div>

<form class="was-validated">
  <div class="mb-3 ">
    <label for="validationTextarea">Sinopse</label>
    <textarea class="form-control " name="sinopse" id="sinopse" placeholder="Digite a sinopse" ></textarea>
    
  </div>
  
  <button type="submit" class="btn btn-primary col-2 " >Enviar</button>
      
</form>
    
      

</div>

<?php

include "fragmentos/rodape.php";